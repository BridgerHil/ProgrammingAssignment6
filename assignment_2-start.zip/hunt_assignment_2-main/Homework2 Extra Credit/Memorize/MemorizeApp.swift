//
//  MemorizeApp.swift
//  Memorize
//
//  Created by Abraham Hunt on 12/29/21.
//

import SwiftUI

@main
struct MemorizeApp: App {
    private let game = EmojiMemoryGame()
    
    var body: some Scene {
        WindowGroup {
            ContentView(viewModel: game)
        }
    }
}
