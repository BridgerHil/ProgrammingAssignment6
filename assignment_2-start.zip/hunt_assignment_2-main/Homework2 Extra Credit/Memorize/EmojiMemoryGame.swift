//
//  EmojiMemoryGame.swift
//  Memorize
//
//  Created by Abraham Hunt on 12/30/21.
//

import Foundation
import SwiftUI

extension MemoryGame.Theme where CardContent == String {
    init(name: String, color: Color, emojis: [String], numberOfPairs: Int?) {
        self.init(name: name, colorMode: .singleColor(color), potentialContent: emojis, cardCountSystem: numberOfPairs.map({ .fixedPairs($0) }))
    }
                  
    static func randomCount(name: String, colorMode: ColorMode, emojis: [String]) -> Self {
        .init(name: name, colorMode: colorMode, potentialContent: emojis, cardCountSystem: .randomCount)
    }
}

class EmojiMemoryGame: ObservableObject {
    
    enum Fill {
        case color(Color)
        case gradient(LinearGradient)
    }
    typealias Game = MemoryGame<String>
    typealias Theme = Game.Theme
    typealias Card = Game.Card
    
    private static let allThemes: [Theme] = [
        .init(name: "Cars", color: .red, emojis: ["🚕","🚔", "🚌", "🚐", "🚗", "🚘", "🚙", "🏎"], numberOfPairs: nil),
        .init(name: "Plants", color: .green, emojis: ["🌵", "🎄", "🌲", "🌳", "🌴", "🌱", "🍀", "🪴", "🎋", "🍂", "🌷", "🥀", "🌺", "🌼", "🌻"], numberOfPairs: nil),
        .init(name: "Animals", color: .blue, emojis: ["🐶", "🐱", "🐭", "🐹", "🐰", "🦊", "🐻", "🐼", "🐻‍❄️", "🐨", "🐯", "🦁", "🐮", "🐷"], numberOfPairs: nil),
        .init(name: "Weather", color: .orange, emojis: ["☀️", "🌤", "⛅️", "🌥", "☁️", "🌦", "🌧", "⛈", "🌩", "🌨", "❄️"], numberOfPairs: nil),
        .init(name: "Moon Phases", color: .black, emojis: ["🌕", "🌖", "🌗", "🌘", "🌑", "🌒", "🌓", "🌔"], numberOfPairs: 3),
        .randomCount(name: "Sports", colorMode: .gradient([.pink, .purple]), emojis: ["⚽️", "🏀", "🏈", "⚾️", "🥎", "🎾", "🏐", "🏉", "🥏", "🎱", "🪀", "🏓", "🏸", "🏒", "🏑", "🥍", "🏏"])
    ]
    
    private static func randomTheme() -> Theme {
        allThemes.randomElement()!
    }
    
    @Published private var model: Game
    @Published private var theme: Theme
    
    convenience init() {
        self.init(theme: Self.randomTheme())
    }
    
    private init(theme: Theme) {
        self.theme = theme
        self.model = theme.createMemoryGame()
    }
    
    var cards: Array<Card> {
        model.cards
    }
    
    var score: Int {
        model.score
    }
    
    var color: Color {
        switch theme.colorMode {
        case .singleColor(let color): return color.swiftUIColor
        case .gradient(let colors): return colors.first!.swiftUIColor
        }
    }
    
    var fill: Fill {
        switch theme.colorMode {
        case .singleColor(let color): return .color(color.swiftUIColor)
        case .gradient(let colors): return .gradient(LinearGradient(colors: colors.map { $0.swiftUIColor }, startPoint: .bottom, endPoint: .top))
        }
    }
    
    var themeName: String {
        theme.name
    }
    
    // MARK: - Intent(s)
    
    func choose(_ card: Card) {
        model.choose(card)
    }
    
    func startNewGame() {
        theme = Self.randomTheme()
        model = theme.createMemoryGame()
    }
}

extension MemoryGame.Theme.Color {
    var swiftUIColor: SwiftUI.Color {
        switch self {
        case .red: return .red
        case .orange: return .orange
        case .yellow: return .yellow
        case .green: return .green
        case .blue: return .blue
        case .purple: return .purple
        case .pink: return .pink
        case .white: return .white
        case .gray: return .gray
        case .black: return .black
        }
    }
}
