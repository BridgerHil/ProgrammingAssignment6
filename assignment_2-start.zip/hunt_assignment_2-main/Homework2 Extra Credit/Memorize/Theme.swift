//
//  Theme.swift
//  Memorize
//
//  Created by Abraham Hunt on 12/30/21.
//

import Foundation

extension MemoryGame {
    struct Theme {
        enum ColorMode {
            case singleColor(Color)
            case gradient([Color])
        }
        enum Color {
            case red
            case orange
            case yellow
            case green
            case blue
            case purple
            case pink
            case white
            case gray
            case black
        }
        
        enum CardCountSystem {
            case fixedPairs(Int)
            case randomCount
        }
        let name: String
        let colorMode: ColorMode
        let potentialContent: [CardContent]
        let cardCountSystem: CardCountSystem?
        
        var pairsForGame: Int {
            switch cardCountSystem {
            case .fixedPairs(let count): return min(count, potentialContent.count)
            case .randomCount: return Int.random(in: 0..<potentialContent.count) // Extra Credit 2
            case .none: return potentialContent.count // Extra Credit 1
            }
        }
                
        func createMemoryGame() -> MemoryGame {
            let content = potentialContent.shuffled()
            return .init(numberOfPairsOfCards: pairsForGame) { pairIndex in content[pairIndex] }
        }
    }
}
